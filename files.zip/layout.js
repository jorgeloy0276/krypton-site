// Edita aquí el nombre y el menú: se aplican a TODAS las páginas.
const BRAND="Krypton Logic";
const NAV=[["Inicio","index.html"],["Sobre Nosotros","sobre-nosotros.html"],["Nuestros Proyectos","proyectos.html"],["Documentation","documentacion.html"],["Preguntas Frecuentes","preguntas-frecuentes.html"],["Contacto","contacto.html"]];
(()=>{
const here=location.pathname.split('/').pop()||'index.html';
// Logo: sustitúyelo por <img src="img/logo.svg" alt=""> cuando tengas el tuyo.
const logo='<svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#8fa8ff"/><stop offset="1" stop-color="#5ee6c8"/></linearGradient></defs><path d="M20 2l15.6 9v18L20 38 4.4 29V11z" stroke="url(#g)" stroke-width="2"/><path d="M14 12v16M14 20l10-8M17.5 17l7.5 11" stroke="url(#g)" stroke-width="2.4" stroke-linecap="round"/></svg>';
const links=NAV.map(([t,h])=>`<a href="${h}"${h===here?' class="on" aria-current="page"':''}>${t}</a>`).join('');
document.getElementById('hdr').innerHTML=`<div class="wrap bar"><a class="brand" href="index.html">${logo}<span>${BRAND}</span></a><button class="burger" aria-label="Abrir menú" aria-expanded="false"><i class="fa-solid fa-bars"></i></button><nav>${links}</nav></div>`;
document.getElementById('ftr').innerHTML=`<div class="wrap foot"><span>© ${new Date().getFullYear()} ${BRAND}. Todos los derechos reservados.</span><nav>${links}</nav></div>`;
const bg=document.querySelector('.burger'),nv=document.querySelector('header nav');
bg.onclick=()=>bg.setAttribute('aria-expanded',nv.classList.toggle('open'));
document.addEventListener('pointermove',e=>{const c=e.target.closest('.card');if(c){const r=c.getBoundingClientRect();c.style.setProperty('--mx',e.clientX-r.left+'px');c.style.setProperty('--my',e.clientY-r.top+'px')}});
const io=new IntersectionObserver(es=>es.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.1});
document.querySelectorAll('.card,.faq details').forEach((el,i)=>{el.classList.add('rv');el.style.animationDelay=(i%4)*70+'ms';io.observe(el)});
})();
